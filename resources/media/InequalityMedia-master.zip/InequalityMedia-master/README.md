#Inequality Media<br>
=============================

<a href="https://kodi.tv/">KODI</a> / <a href="https://kodi.tv/">XMBC</a> / <a href="https://www.firesticktricks.com/install-kodi-on-fire-stick.html">Firestick</a> video addon for the <a href="http://www.inequalitymedia.org/">Inequality Media</a> videos.<br>


<a href="https://inequalitymedia.org">InequalityMedia.org</a>

We are a nonpartisan digital media company with a mission.  We produce compelling original video, share our content through social and traditional media to raise awareness about the issues, and partner with leading organizations to provide an avenue through which viewers can engage, mobilize, and take action.<br>

^^^ To install this addon, either use the <a href="https://www.tvaddons.co/github-browser-kodi/">Kodi Github installer</a> addon or save the .zip file downloaded from the 'clone or download' button above to somewhere the Kodi can access (e.g. network drive, USB, etc). Then on the Kodi, go to addons > install from zip file.<br>

<a href="https://inequalitymedia.org/"><img src="https://pbs.twimg.com/profile_images/702984762432970752/-Wl738OT_400x400.jpg">
